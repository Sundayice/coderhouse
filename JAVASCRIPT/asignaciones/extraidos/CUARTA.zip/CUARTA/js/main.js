alert('Desafío cuatro: Programacion avanzada con funciones (Carlos Padilla)');

let edadusuario = prompt('¿Cuál es su edad?');
let identidadid = prompt('¿Cuál es su número de identidad?')

if (!edadusuario){
    alert('No ha ingresado su edad!!!')
} else{
    console.log('Edad del Usuario: ' + edadusuario);
}

if (!identidadid){
    alert('No ingresó su número de identificación!!!')
}else{
    console.log('Número de identificación del usuario: ' + identidadid)
}
