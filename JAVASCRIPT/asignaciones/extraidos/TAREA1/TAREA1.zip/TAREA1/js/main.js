alert('Desafío uno:  Crear un algoritmo JS simple (Carlos Padilla)')

var nombreDelEstudiante = 'Carlos'
let apellidoDelEstudiante = 'Padilla'
let espacio = ' '
console.log('Nombre del Estudiante: '+nombreDelEstudiante)
console.log('Apellido: '+apellidoDelEstudiante)

console.log('Lo dos juntos: '+nombreDelEstudiante+espacio+apellidoDelEstudiante)