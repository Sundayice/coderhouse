// // /* CON FOR */
for (let i = 1; i <=6; i++) {
    console.log('iteración ${i}');
}
console.log('fin del ciclo 1 a 6');


/* AL REVÉS */
 for (let i = 4; i >= 1; i--){ 
     console.log('teración ${i}');
}
console.log('Fin del ciclo 4 a 1');

/* ANIDADOS */
for (let i = 1; i <= 4; i++){
    console.log('empieza iteración ${i}');
    for (let j = 0; j < 4; j++){
        console.log(j)
    }
}
console.log('fin del ciclo');

/* WHILE */
let x = 1;
while (x <= 4){
    console.log('iteracion ${x}');
    x++;
}
console.log('fin de while')

/* DO WHILE */
let y = 1;
do{
    console.log('iteracion ${y}')
    y++;

}while (y <= 4)
console.log('fin de la iteración')



/*Carlos Padilla*/